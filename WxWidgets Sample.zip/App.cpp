﻿#include "App.h"

// Define the MyApp::OnInit method
bool MyApp::OnInit() {
    // Create and show the main frame
    MyFrame* frame = new MyFrame("Hello World", wxDefaultPosition, wxDefaultSize);
    frame->Show(true);
    return true;
}

// Implement the wxApp entry point
wxIMPLEMENT_APP(MyApp);

// Define the MyFrame constructor
MyFrame::MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size)
    : wxFrame(nullptr, wxID_ANY, title, pos, size) {
    // Set up the grid sizer
    wxSizerFlags flags = wxSizerFlags().Expand();
    wxGridSizer* sizer = new wxGridSizer(3, 3, 20, 20);

    // Create and add buttons to the sizer
    for (int i = 0; i < 9; i++) {
        buttons[i] = new wxButton(this, ButtonIds(but0 + i), "Clicky", wxDefaultPosition, wxSize(50, 50));
        buttons[i]->Bind(wxEVT_BUTTON, &MyFrame::OnCommandEvent, this);
        BUTTON_REFS[but0 + i] = buttons[i];
        sizer->Add(buttons[i], flags);
    }

    // Set the sizer and size hints for the frame
    SetSizer(sizer);
    sizer->SetSizeHints(this);

    // Create the status bar
    CreateStatusBar();
}

// Define the event handler for button presses
void MyFrame::OnCommandEvent(wxCommandEvent& evt) {
    wxLogStatus(wxString::Format("Pressed Id: %d", evt.GetId()));
    BUTTON_REFS[evt.GetId()]->SetLabelText("YAY");
    evt.Skip();
}
