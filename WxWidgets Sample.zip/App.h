#pragma once
#include "GLOBALS.h"
// Declare the MyApp class derived from wxApp
class MyApp : public wxApp {
public:
    virtual bool OnInit() override;
};

// Declare the MyFrame class derived from wxFrame
class MyFrame : public wxFrame {
public:
    MyFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
    void OnCommandEvent(wxCommandEvent& evt);
private:
    wxButton* buttons[9];
};

enum ButtonIds {
    but0 = wxID_HIGHEST + 1,
    but1,
    but2,
    but3,
    but4,
    but5,
    but6,
    but7,
    but8,
};
