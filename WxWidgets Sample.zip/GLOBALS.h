#pragma once
#include <wx/wx.h>
#include <unordered_map>
#define id_map(type) std::unordered_map<int, type>
id_map(wxButton*) BUTTON_REFS;